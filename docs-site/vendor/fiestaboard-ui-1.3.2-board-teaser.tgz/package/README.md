# FiestaUI

FiestaUI is the [FiestaBoard](https://github.com/Fiestaboard/FiestaBoard) design system: React components built on [Base UI](https://base-ui.com) with Tailwind v4 design tokens, published as [`@fiestaboard/ui`](https://www.npmjs.com/package/@fiestaboard/ui).

**Component catalog:** the Storybook is deployed to GitHub Pages on every push to `main`.

## Installation

The package is published to the **GitHub Packages npm registry** (not npmjs.com — yet). GitHub Packages requires authentication to install, even for public packages, so consumers need a one-time setup:

1. Create a [personal access token](https://github.com/settings/tokens) with the `read:packages` scope.
2. Configure npm (in `~/.npmrc`, NOT committed to any repo):

   ```ini
   @fiestaboard:registry=https://npm.pkg.github.com
   //npm.pkg.github.com/:_authToken=YOUR_TOKEN
   ```

3. Install:

   ```bash
   npm install @fiestaboard/ui
   ```

In GitHub Actions, use the workflow's `GITHUB_TOKEN` (with `packages: read`) as `NODE_AUTH_TOKEN` via `actions/setup-node`'s `registry-url`/`scope` options instead of a PAT.

Peer dependencies: `react` / `react-dom` ^19, `lucide-react`, and `tailwindcss` ^4 in the consuming app.

## Styling contract

FiestaUI ships **no compiled utility CSS**. The consuming app runs Tailwind v4 and generates utilities for the class strings inside this package. In your Tailwind entry CSS:

```css
@import "tailwindcss";
@import "@fiestaboard/ui/theme.css";
@source "../node_modules/@fiestaboard/ui/dist";
```

- `theme.css` carries the design tokens (`@theme inline`, `:root` / `.dark` custom properties), the base layer, the component animation keyframes, the Geist font-face registrations, and the `dark` custom variant.
- The `@source` line is **mandatory** — Tailwind v4 does not scan `node_modules` by default, and without it component styles silently vanish. Adjust the relative path to wherever your CSS file lives.
- Dark mode is class-based: toggle the `dark` class on `<html>`. FiestaUI only defines the variant; your app owns the toggle.

## Usage

```tsx
import { Button, Card, CardContent, cn } from "@fiestaboard/ui";

export function Example() {
  return (
    <Card>
      <CardContent className={cn("flex gap-2 p-4")}>
        <Button variant="brand">Save</Button>
        <Button variant="outline">Cancel</Button>
      </CardContent>
    </Card>
  );
}
```

## Development

```bash
npm install
npm run storybook        # component workbench on :6006
npm run build            # dist/ — ESM + d.ts + theme.css
npm run lint && npm run typecheck && npm run format:check
npm run build-storybook && npm run test-storybook   # axe a11y sweep (needs the static build served on :6006)
```

### Visual parity rule

This package was extracted from FiestaBoard's `web/src/components/ui` with a pixel-parity guarantee. Token values in `src/styles/theme.css` and component class strings are contract, not implementation detail — changes to them are visible in every consumer. Change intentionally and version accordingly (patch: fixes, minor: additive components/variants, major: breaking API or visual changes).

### Testing against a local consumer

Don't point FiestaBoard's Docker build at an unpublished version. For local iteration:

```bash
npm run build && npm pack   # produces fiestaboard-ui-<version>.tgz
# in the consumer: npm install /path/to/fiestaboard-ui-<version>.tgz
```

## Releasing

Releases are manual: **Actions → Release → Run workflow**, choosing a `patch` / `minor` / `major` bump. The workflow bumps the version, tags `v<version>`, publishes to npm, and creates a GitHub Release.

Publishing authenticates with the workflow's built-in `GITHUB_TOKEN` (`packages: write`) — no npm account, no long-lived secrets, nothing to rotate.

If the package later moves to registry.npmjs.org (which would allow anonymous installs), switch the release workflow to [npm Trusted Publishing](https://docs.npmjs.com/trusted-publishers/) (OIDC); note that npm's [bypass-2FA token deprecation](https://github.blog/changelog/2026-07-08-npm-install-time-security-and-gat-bypass2fa-deprecation/) means the first npmjs publish must be done manually with a 2FA OTP.

## Downstream upgrade automation

Every release triggers `.github/workflows/downstream-upgrade.yml`, which keeps
a single evergreen PR open on `Fiestaboard/FiestaBoard` (branch
`fiestaui-upgrade`) pinning `@fiestaboard/ui` to the newest version. If the
bump breaks FiestaBoard, Claude (Opus) TDD-fixes it (max 3 attempts) and
FiestaBoard CI must pass before the PR is labeled `upgrade-green`; otherwise
it's labeled `upgrade-blocked` and the maintainer is pinged. A human on
FiestaBoard always does the merge.

Manual run / backfill: **Actions → Downstream Upgrade → Run workflow**
(optionally set `version`; `dry_run` computes the bump without pushing).

Required repo secrets: `CLAUDE_BOT_APP_ID`, `CLAUDE_BOT_APP_PRIVATE_KEY`
(GitHub App with write access to FiestaBoard), `CLAUDE_CODE_OAUTH_TOKEN`.
Design: `docs/superpowers/specs/2026-08-01-downstream-upgrade-design.md`.

## License

MIT
